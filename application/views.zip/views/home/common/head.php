<meta charset="utf-8">
<?php if ($this->uri->segment(1) == "about") { ?>
    <title>Dentist in Miyapur, Hydernagar | Peoples Dental Care</title>
    <meta name="Description" content="Dentist in Miyapur, Hydernagar, kukatpally, peoples dental care is a highly advanced Dental Clinic in miyapur, hyderanagar. Our Dentist in kukatpally are specialize in all types of dental care services"/>
    <meta name="Keywords" content="Dental clinic hydernagar, Dental clinic in hydernagar, Dental hospital hydernagar, Dental hospital in hydernagar, Dentist hydernagar, Dentist  in hydernagar, Orthodontist hydernagar, Orthodontist in hydernagar, Dental clinic kukatpally, Dental clinic in kukatpally, Dental hospital kukatpally, Dental hospital in kukatpally, Dentist kukatpally, Dentist in kukatpally, Orthodontist kukatpally, Orthodontist in kukatpally, Dental clinic miyapur, Dental clinic in miyapur, Dental hospital miyapur, Dental hospital in miyapur, Dentist  miyapur, Dentist in miyapur, Orthodontist miyapur, Orthodontist in  miyapur, Dental clinic nizampet, Dental clinic in nizampet, Dental hospital nizampet, Dental hospital in nizampet, Dentist in nizampet, Dentist in nizampet, Orthodontist nizampet, Orthodontist in  nizampet" />
<?php } else if ($this->uri->segment(1) == "treatments") { ?>
    <title>dental treatments | people's dental care in hydernagar, nizampet, miyapur,  kukatpally, hyderabad</title>
    <meta name="Description" content="People dental care staff highly specified in Child Dentistry, Dental Implants, Teeth Whitening, Root Canal Treatment, Oral Surgery, Gum Treatments in hydernagar, Nizampet, miyapur, kukatpally, Hyderabad"/>
    <meta name="Keywords" content="Dental clinic hydernagar, Dental clinic in hydernagar, Dental hospital hydernagar, Dental hospital in hydernagar, Dentist hydernagar, Dentist  in hydernagar, Orthodontist hydernagar, Orthodontist in hydernagar, Dental clinic kukatpally, Dental clinic in kukatpally, Dental hospital kukatpally, Dental hospital in kukatpally, Dentist kukatpally, Dentist in kukatpally, Orthodontist kukatpally, Orthodontist in kukatpally, Dental clinic miyapur, Dental clinic in miyapur, Dental hospital miyapur, Dental hospital in miyapur, Dentist  miyapur, Dentist in miyapur, Orthodontist miyapur, Orthodontist in  miyapur, Dental clinic nizampet, Dental clinic in nizampet, Dental hospital nizampet, Dental hospital in nizampet, Dentist in nizampet, Dentist in nizampet, Orthodontist nizampet, Orthodontist in  nizampet" />
<?php } else if ($this->uri->segment(1) == "patientcare") { ?>
    <title>Dental clinic in miyapur, hydernagar, hyderabad | peoples dental care</title>
    <meta name="Description" content="We are one of the best dental clinic in miyapur, hydernagar, hyderabad, Our Dentist provide high quality affordable dental treatments. We have clinic in hydernagar, nizampet, kukatpally, hyderabad"/>
    <meta name="Keywords" content="Dental clinic hydernagar, Dental clinic in hydernagar, Dental hospital hydernagar, Dental hospital in hydernagar, Dentist hydernagar, Dentist  in hydernagar, Orthodontist hydernagar, Orthodontist in hydernagar, Dental clinic kukatpally, Dental clinic in kukatpally, Dental hospital kukatpally, Dental hospital in kukatpally, Dentist kukatpally, Dentist in kukatpally, Orthodontist kukatpally, Orthodontist in kukatpally, Dental clinic miyapur, Dental clinic in miyapur, Dental hospital miyapur, Dental hospital in miyapur, Dentist  miyapur, Dentist in miyapur, Orthodontist miyapur, Orthodontist in  miyapur, Dental clinic nizampet, Dental clinic in nizampet, Dental hospital nizampet, Dental hospital in nizampet, Dentist in nizampet, Dentist in nizampet, Orthodontist nizampet, Orthodontist in  nizampet" />
<?php } else if ($this->uri->segment(1) == "gallery") { ?>
    <title>Gallery | people's dental care in hydernagar,nizampet, miyapur, kukatpally</title>
    <meta name="Description" content="View of people's dental care clinic hospital, It is hydernagar, nizampet, miyapur, kukatpally,  hyderabad first  hospital committed to the advanced medical care that enhances the value of human life"/>
    <meta name="Keywords" content="Dental clinic hydernagar, Dental clinic in hydernagar, Dental hospital hydernagar, Dental hospital in hydernagar, Dentist hydernagar, Dentist  in hydernagar, Orthodontist hydernagar, Orthodontist in hydernagar, Dental clinic kukatpally, Dental clinic in kukatpally, Dental hospital kukatpally, Dental hospital in kukatpally, Dentist kukatpally, Dentist in kukatpally, Orthodontist kukatpally, Orthodontist in kukatpally, Dental clinic miyapur, Dental clinic in miyapur, Dental hospital miyapur, Dental hospital in miyapur, Dentist  miyapur, Dentist in miyapur, Orthodontist miyapur, Orthodontist in  miyapur, Dental clinic nizampet, Dental clinic in nizampet, Dental hospital nizampet, Dental hospital in nizampet, Dentist in nizampet, Dentist in nizampet, Orthodontist nizampet, Orthodontist in  nizampet" />
<?php } else if ($this->uri->segment(1) == "booknow") { ?>
    <title>Dental Clinic in Nizampet, hydernagar | Peoples dental care hospital</title>
    <meta name="Description" content="We are one of the best dental clinic in nizampet, hydernagar, kukatpally, hyderabad,, Leading family dentist in nizampet, hydernagar offering all types of dental treatments, Best smile makeover dental clinic"/>
    <meta name="Keywords" content="Dental clinic hydernagar, Dental clinic in hydernagar, Dental hospital hydernagar, Dental hospital in hydernagar, Dentist hydernagar, Dentist  in hydernagar, Orthodontist hydernagar, Orthodontist in hydernagar, Dental clinic kukatpally, Dental clinic in kukatpally, Dental hospital kukatpally, Dental hospital in kukatpally, Dentist kukatpally, Dentist in kukatpally, Orthodontist kukatpally, Orthodontist in kukatpally, Dental clinic miyapur, Dental clinic in miyapur, Dental hospital miyapur, Dental hospital in miyapur, Dentist  miyapur, Dentist in miyapur, Orthodontist miyapur, Orthodontist in  miyapur, Dental clinic nizampet, Dental clinic in nizampet, Dental hospital nizampet, Dental hospital in nizampet, Dentist in nizampet, Dentist in nizampet, Orthodontist nizampet, Orthodontist in  nizampet" />
<?php } else { ?>
    <title>Best dentist | Dental Clinic hospital In HyderNagar, Nizampet, Kukatpally, Miyapur, hyderabad</title>
    <meta name="Description" content="peoples dental care is the one of best dental clinic hospital in Hydernagar, nizampet, miyapur, kukatpally, hyderabad. best dentist, prosthodontics, Orthodontist in Hydernagar, nizampet, miyapur, kukatpally, hyderabad,, we are specialized in Teeth Whitening & cleaning, Root Canal Treatment,Oral Surgery, Gum Treatments, Orthodontist, Dental Implants, Child Dentistry, Orthodontic Treatment, Crowns and bridges Etc,,,Hydernagar, nizampet, miyapur, kukatpally, hyderabad"/>
    <meta name="Keywords" content="Dental clinic hydernagar, Dental clinic in hydernagar, Dental hospital hydernagar, Dental hospital in hydernagar, Dentist hydernagar, Dentist  in hydernagar, Orthodontist hydernagar, Orthodontist in hydernagar, Dental clinic kukatpally, Dental clinic in kukatpally, Dental hospital kukatpally, Dental hospital in kukatpally, Dentist kukatpally, Dentist in kukatpally, Orthodontist kukatpally, Orthodontist in kukatpally, Dental clinic miyapur, Dental clinic in miyapur, Dental hospital miyapur, Dental hospital in miyapur, Dentist  miyapur, Dentist in miyapur, Orthodontist miyapur, Orthodontist in  miyapur, Dental clinic nizampet, Dental clinic in nizampet, Dental hospital nizampet, Dental hospital in nizampet, Dentist in nizampet, Dentist in nizampet, Orthodontist nizampet, Orthodontist in  nizampet" />
<?php } ?>
<meta name="google-site-verification" content="C6bKrTSFx-fqNZDBvJuOmiJg9iTNiA0J9pli8PI6ujQ" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="<?= config_item('root_dir'); ?>assets/images/fav/favicon.png">

<link href="<?= config_item('root_dir'); ?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= config_item('root_dir'); ?>assets/css/fontawesome-all.min.css" rel="stylesheet">
<link href="<?= config_item('root_dir'); ?>assets/css/magnific-popup.css" rel="stylesheet">
<link href="<?= config_item('root_dir'); ?>assets/css/owl.carousel.css" rel="stylesheet">
<link href="<?= config_item('root_dir'); ?>assets/css/styles/style.css" rel="stylesheet">
<link href="<?= config_item('root_dir'); ?>assets/css/styles/skin-lblue.css" rel="stylesheet" id="color_theme">
<link href="<?= config_item('root_dir'); ?>assets/css/custom.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?= config_item('root_dir'); ?>assets/css/style_common.css" />
<link rel="stylesheet" type="text/css" href="<?= config_item('root_dir'); ?>assets/css/style8.css" />

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-81206033-1', 'auto');
    ga('send', 'pageview');
</script>

<script type="text/javascript">
    var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
    (function () {
        var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/579ceb49c0f4ac7924b2c2ab/default';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script src='https://www.google.com/recaptcha/api.js'></script>

<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'hi,te', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    }
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script type="text/javascript">
    (function (d, s, id) {
        var js, script = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {
            return;
        }
        js = d.createElement(s);
        js.id = id;
        js.async = true;
        js.src = "https://www.practo.com/bundles/practopractoapp/js/marketing/doc-widget.js";
        script.parentNode.insertBefore(js, script);
    })(document, 'script', 'practo-widget-js');
</script>

<style>
    #practo-widget-wrapper{height: 30px; margin: auto; text-align: center;}
    .practo-appt-button{background:url(<?= config_item('root_dir'); ?>assets/images/fix.png) !important; width:100%; height: 28px;}
    .practo-appt-button img{display:none;}
    .practo-widget{background:none !important;box-shadow: 0px 0 0px #aeaeae !important; height:auto; padding:0px; margin:0px;height: 30px; width: 180px; background:#5cb85c; border:1px solid #fff;}
    .practo-footer{display:none !important;}
    .goog-te-gadget-simple {background-color: #fff;border:none;font-size: 10px;display: inline-block;padding-top: 0px;padding-bottom: 0px;cursor: pointer;zoom: 1;}
</style>
