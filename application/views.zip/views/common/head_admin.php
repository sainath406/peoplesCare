<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?= $title; ?></title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/components/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/components/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/components/Ionicons/css/ionicons.min.css">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/dist/css/AdminLTE.min.css">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/plugins/iCheck/square/blue.css">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/dist/css/skins/_all-skins.min.css">
<link href="https://fonts.googleapis.com/css?family=Work+Sans|Raleway|Montserrat|Cinzel|Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic" rel="stylesheet">
<link rel="stylesheet" href="<?= config_item('root_dir'); ?>assets/admin/css/common.css">