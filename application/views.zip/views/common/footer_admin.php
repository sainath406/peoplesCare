<script src="<?= config_item('root_dir'); ?>assets/admin/components/jquery/dist/jquery.min.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/components/fastclick/lib/fastclick.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/dist/js/adminlte.min.js"></script>
<script src="<?= config_item('root_dir'); ?>assets/admin/dist/js/demo.js"></script>